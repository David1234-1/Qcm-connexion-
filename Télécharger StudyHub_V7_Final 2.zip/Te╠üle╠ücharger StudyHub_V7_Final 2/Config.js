// config.js
window.StudyHubConfig = {
  firebase: {
    apiKey: "AIzaSyCqGSBrsJ-7PIpfjAM58gD8h4VcY793rWQ",
    authDomain: "studyhub-proje.firebaseapp.com",
    projectId: "studyhub-proje",
    storageBucket: "studyhub-proje.appspot.com",
    messagingSenderId: "359347355393",
    appId: "1:359347355393:web:8c05ede417c10c272d6500",
    measurementId: "G-DMQJNJW9S0"
  }
};